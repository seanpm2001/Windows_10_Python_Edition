This license pack is an add-on for our Windows 10 Python Edition project
early versions of the program do not come with this, and you may have
downloaded this as a replacement to a deleted license pack, or to add
the license pack to an older version
this contains the GNU 3 license, and the creative commons license in
text document, word document, and rich text document formats. These
protect your work as "fair use" as these projects were not meant to 
steal the idea of "Windows 10" "Windows" "Microsoft" or other features
that we used, as they fall under fair use
even without the license, the projects are still protected, as they
do not violate copyright, or violate the law. These licenses are
extra security, and they are open source too, so you can port them
to your projects, or other projects as well